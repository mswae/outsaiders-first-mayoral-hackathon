import pandas as pd
import os
import warnings

def ingest_feedback(file):
    try:
        feedback_df = pd.read_csv(file, encoding="utf-8", encoding_errors="replace")
    except UnicodeDecodeError:
        feedback_df = pd.read_csv(file, encoding="latin-1", encoding_errors="replace")  # or cp1252

    feedback_volume = len(feedback_df)

    return feedback_df, feedback_volume

def ingest_adoption(file):

    # --- Validation ---
    if file is None or file == "":
        warnings.warn("Adoption file is empty; participants_by_group will be empty")
        return {}
    
    if not os.path.exists(file):
        warnings.warn("Adoption file is empty; participants_by_group will be empty")
        return {}
    try:
        adoption_df = pd.read_csv(file, encoding="utf-8", encoding_errors="replace")
    except UnicodeDecodeError:
        adoption_df = pd.read_csv(file, encoding="latin-1", encoding_errors="replace")

    if adoption_df.empty:
        warnings.warn("Adoption file is empty; participants_by_group will be empty")
        return {}
    
    # handle missing required column
    # there must be a "group" column in the adoption dataset
    if "group" not in adoption_df.columns:
        raise ValueError("Adoption data must contain \"group\" column.")

    participants_by_group = adoption_df.groupby("group").size().to_dict()

    return participants_by_group