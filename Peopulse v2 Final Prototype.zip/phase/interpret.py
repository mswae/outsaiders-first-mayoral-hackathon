def assign_typology(components):

    # define state rules for every components
    STATE_RULES = {
        "PCR (Participation Coverage Ratio)": [
            (50.0, "Low Alert"),
            (20.0, "Medium Alert"),
            (0.0, "High Alert")
        ],
        "SPI-A (Silent Participation Inference - Silent Non-Adoption)": [
            (50.0, "High Alert"),
            (20.0, "Medium Alert"),
            (0.0, "Low Alert")
        ],
        "SPI-B (Silent Participation Inference - Silent Adoption)": [
            (60.0, "High Alert"),
            (30.0, "Medium Alert"),
            (0.0, "Low Alert")
        ],
        "PEG (Participation-to-Expression Gap)": [
            (60.0, "High Alert"),
            (30.0, "Medium Alert"),
            (0.0, "Low Alert")
        ]
    }
    
    buckets = {
        "High Alert": [],
        "Medium Alert": [],
        "Low Alert": []
    }

    for component, data in components.items():
        value = data["Value"]
        description = data.get("Description", "")

        for threshold, state in STATE_RULES[component]:
            if value >= threshold:
                buckets[state].append({
                    "Component": component,
                    "Value": value,
                    "Description": description
                })
                break

    return buckets
