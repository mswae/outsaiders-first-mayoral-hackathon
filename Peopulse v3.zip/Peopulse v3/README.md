---
title: Peopulse
emoji: 📊
colorFrom: pink
colorTo: purple
sdk: gradio
sdk_version: 6.2.0
app_file: app.py
pinned: false
license: cc-by-nc-nd-4.0
short_description: Silence-Aware Citizen Feedback Intelligence System
---

Check out the configuration reference at https://huggingface.co/docs/hub/spaces-config-reference