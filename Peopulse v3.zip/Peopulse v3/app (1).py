import gradio as gr

from phase.ingestion import ingest_feedback, ingest_adoption
from phase.sentiment_modeling import transform_sentiments, compute_sentiment_metrics
from phase.compute import ParticipationAdoptionIndex
from phase.interpret import assign_typology

def run_app(feedback_file, attendance_file, num_participants, target_population):
        
    # Step 1: Ingest data
    df, feedback_volume = ingest_feedback(feedback_file)
    participants_by_group = ingest_adoption(attendance_file)

    # Step 2: Sentiment modeling
    processed_df, sorted_sentiments = transform_sentiments(df)
    sentiment_metrics = compute_sentiment_metrics(processed_df, feedback_volume)

    # Step 3: Compute Participation Adoption Index (PAI)
    pai_calculator = ParticipationAdoptionIndex(
        num_participants=num_participants,
        target_population=target_population,
        feedback_volume=feedback_volume
    )

    pai_1, pai_2 = pai_calculator.compute_pai(participants_by_group)

    # Step 4: Interpret results
    typology = assign_typology(pai_1)

    return sentiment_metrics, sorted_sentiments, typology, pai_2

# ========== GRADIO INTERFACE ==========
with gr.Blocks() as demo:
    gr.Markdown("# 🏙️📊Peopulse: Citizen Feedback Intelligence System")

    # ----- INPUTS -----
    with gr.Row():
        feedback_file_input = gr.File(label="Upload Feedback Data (CSV)")
        attendance_file_input = gr.File(label="Upload Attendance Data (CSV)")
    with gr.Row():
        gr.Markdown("⚠️Note: Ignore 'Number of Participants' field if there is Attendance Data. Otherwise, please set 'Number of Participants' field.")

    with gr.Row():
        num_participants_input = gr.Number(
            label="Number of Participants",
            value=100,
            minimum=0,
            maximum=1e9,
            step=1,
            precision=0
        )
        target_population_input = gr.Number(
            label="Target Population Size",
            value=1000,
            minimum=1,
            maximum=1e10,
            step=1,
            precision=0
        )

    btn = gr.Button("Run Diagnostics")

    # ----- OUTPUTS -----
    with gr.Row():
        with gr.Column(scale=3):
            gr.Markdown("## 📊🗨️ Public Sentiments")
            sorted_sentiments_output = gr.DataFrame(
                show_label=True,
                show_row_numbers=True,
                max_height=300,
                interactive=False,
                wrap=True
            )
        with gr.Column(scale=2):
            gr.Markdown("## 🗨️📈Public Sentiment Analytics")
            sentiment_metrics_output = gr.JSON()
    with gr.Row():
        with gr.Column(scale=1):
            gr.Markdown("## 📃🩺Participation Dynamics")
            typology_output = gr.JSON()
        with gr.Column(scale=1):
            gr.Markdown("## 📃🩺Reach & Equity")
            pai_2_output = gr.JSON()             

    btn.click(
        fn=run_app,
        inputs=[feedback_file_input, attendance_file_input, num_participants_input, target_population_input],
        outputs=[sentiment_metrics_output, sorted_sentiments_output, typology_output, pai_2_output]
    )
    
demo.launch()